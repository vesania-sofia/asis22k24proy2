﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Capa_Vista_Produccion
{
    public partial class Frm_Enlace_Contabilidad_Cierre : Form
    {
        public Frm_Enlace_Contabilidad_Cierre()
        {
            InitializeComponent();
        }
    }
}
