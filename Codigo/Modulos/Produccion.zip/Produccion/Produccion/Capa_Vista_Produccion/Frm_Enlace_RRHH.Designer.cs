﻿
namespace Capa_Vista_Produccion
{
    partial class Frm_Enlace_RRHH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Btn_consultar_empleado = new System.Windows.Forms.Button();
            this.Btn_generar_reporte_empleado = new System.Windows.Forms.Button();
            this.Btn_ver_departamento = new System.Windows.Forms.Button();
            this.Btn_salir = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Txt_id_empleado = new System.Windows.Forms.TextBox();
            this.Txt_nombre_empleado = new System.Windows.Forms.TextBox();
            this.Txt_departamento = new System.Windows.Forms.TextBox();
            this.Txt_puesto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Dgv_empleados = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_empleados)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_consultar_empleado
            // 
            this.Btn_consultar_empleado.Location = new System.Drawing.Point(12, 64);
            this.Btn_consultar_empleado.Name = "Btn_consultar_empleado";
            this.Btn_consultar_empleado.Size = new System.Drawing.Size(103, 48);
            this.Btn_consultar_empleado.TabIndex = 0;
            this.Btn_consultar_empleado.Text = "Consultar Empleado";
            this.Btn_consultar_empleado.UseVisualStyleBackColor = true;
            // 
            // Btn_generar_reporte_empleado
            // 
            this.Btn_generar_reporte_empleado.Location = new System.Drawing.Point(242, 64);
            this.Btn_generar_reporte_empleado.Name = "Btn_generar_reporte_empleado";
            this.Btn_generar_reporte_empleado.Size = new System.Drawing.Size(108, 48);
            this.Btn_generar_reporte_empleado.TabIndex = 1;
            this.Btn_generar_reporte_empleado.Text = "Generar Reporte";
            this.Btn_generar_reporte_empleado.UseVisualStyleBackColor = true;
            // 
            // Btn_ver_departamento
            // 
            this.Btn_ver_departamento.Location = new System.Drawing.Point(121, 64);
            this.Btn_ver_departamento.Name = "Btn_ver_departamento";
            this.Btn_ver_departamento.Size = new System.Drawing.Size(115, 48);
            this.Btn_ver_departamento.TabIndex = 1;
            this.Btn_ver_departamento.Text = "Ver Departamento";
            this.Btn_ver_departamento.UseVisualStyleBackColor = true;
            // 
            // Btn_salir
            // 
            this.Btn_salir.Location = new System.Drawing.Point(356, 64);
            this.Btn_salir.Name = "Btn_salir";
            this.Btn_salir.Size = new System.Drawing.Size(108, 48);
            this.Btn_salir.TabIndex = 2;
            this.Btn_salir.Text = "Salir";
            this.Btn_salir.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(150, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(191, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enlace a Recursos Humanos";
            // 
            // Txt_id_empleado
            // 
            this.Txt_id_empleado.Location = new System.Drawing.Point(261, 149);
            this.Txt_id_empleado.Name = "Txt_id_empleado";
            this.Txt_id_empleado.Size = new System.Drawing.Size(202, 22);
            this.Txt_id_empleado.TabIndex = 4;
            // 
            // Txt_nombre_empleado
            // 
            this.Txt_nombre_empleado.Location = new System.Drawing.Point(261, 177);
            this.Txt_nombre_empleado.Name = "Txt_nombre_empleado";
            this.Txt_nombre_empleado.Size = new System.Drawing.Size(202, 22);
            this.Txt_nombre_empleado.TabIndex = 5;
            // 
            // Txt_departamento
            // 
            this.Txt_departamento.Location = new System.Drawing.Point(261, 205);
            this.Txt_departamento.Name = "Txt_departamento";
            this.Txt_departamento.Size = new System.Drawing.Size(202, 22);
            this.Txt_departamento.TabIndex = 6;
            // 
            // Txt_puesto
            // 
            this.Txt_puesto.Location = new System.Drawing.Point(261, 233);
            this.Txt_puesto.Name = "Txt_puesto";
            this.Txt_puesto.Size = new System.Drawing.Size(202, 22);
            this.Txt_puesto.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 205);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Departamento";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Nombre";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 233);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Puesto";
            // 
            // Dgv_empleados
            // 
            this.Dgv_empleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_empleados.Location = new System.Drawing.Point(15, 284);
            this.Dgv_empleados.Name = "Dgv_empleados";
            this.Dgv_empleados.RowHeadersWidth = 51;
            this.Dgv_empleados.RowTemplate.Height = 24;
            this.Dgv_empleados.Size = new System.Drawing.Size(448, 154);
            this.Dgv_empleados.TabIndex = 11;
            // 
            // Frm_Enlace_RRHH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 450);
            this.Controls.Add(this.Dgv_empleados);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Txt_puesto);
            this.Controls.Add(this.Txt_departamento);
            this.Controls.Add(this.Txt_nombre_empleado);
            this.Controls.Add(this.Txt_id_empleado);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Btn_salir);
            this.Controls.Add(this.Btn_ver_departamento);
            this.Controls.Add(this.Btn_generar_reporte_empleado);
            this.Controls.Add(this.Btn_consultar_empleado);
            this.Name = "Frm_Enlace_RRHH";
            this.Text = "Frm_Enlace_RRHH";
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_empleados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Btn_consultar_empleado;
        private System.Windows.Forms.Button Btn_generar_reporte_empleado;
        private System.Windows.Forms.Button Btn_ver_departamento;
        private System.Windows.Forms.Button Btn_salir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Txt_id_empleado;
        private System.Windows.Forms.TextBox Txt_nombre_empleado;
        private System.Windows.Forms.TextBox Txt_departamento;
        private System.Windows.Forms.TextBox Txt_puesto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView Dgv_empleados;
    }
}